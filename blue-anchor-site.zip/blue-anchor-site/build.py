#!/usr/bin/env python3
"""Assemble the site pages from partials/ + pages/. Run: python3 build.py"""
import os, re

ROOT = os.path.dirname(os.path.abspath(__file__))
top = open(os.path.join(ROOT, 'partials/top.html')).read()
footer = open(os.path.join(ROOT, 'partials/footer.html')).read()

NAV = [
    ('index.html', 'Home'),
    ('menu.html', 'Menu'),
    ('reservations.html', 'Reservations'),
    ('about.html', 'About Us'),
    ('https://www.toasttab.com/blue-anchor-166-river-drive', 'Online Order/Pickup'),
    ('gift-cards.html', 'Gift Cards'),
    ('captains-club.html', "The Captain's Club"),
]

PAGES = {
    'index.html': ('Blue Anchor | Waterfront Seafood Restaurant in Jersey City', 'Blue Anchor is a waterfront seafood restaurant in Newport, Jersey City, serving oysters, lobster rolls, sushi, bao buns, burgers and steaks with NYC skyline views. Craft cocktails and live music every Tuesday.'),
    'menu.html': ('Menu — Blue Anchor', "Explore Blue Anchor's lunch, dinner, brunch, bao & sushi, happy hour and drinks menus in Jersey City."),
    'reservations.html': ('Reservations — Blue Anchor', 'Reserve a table at Blue Anchor, waterfront seafood in Newport, Jersey City.'),
    'about.html': ('About Us — Blue Anchor', 'Waterfront views meet elevated casual seafood in Newport, Jersey City.'),
    'gift-cards.html': ('Gift Cards — Blue Anchor', 'Give someone a night on the waterfront with a Blue Anchor gift card.'),
    'captains-club.html': ("The Captain's Club — Blue Anchor", "Join Blue Anchor's rewards program and earn on every visit."),
}

def nav_html(current):
    links = []
    for href, label in NAV:
        cls = ' class="active" aria-current="page"' if href == current else ''
        ext = ' target="_blank" rel="noopener"' if href.startswith('http') else ''
        links.append(f'      <a href="{href}"{cls}{ext}>{label}</a>')
    return '\n'.join(links)

for fname, (title, desc) in PAGES.items():
    body = open(os.path.join(ROOT, 'pages', fname)).read()
    page = top
    page = re.sub(r'<title>.*?</title>', f'<title>{title}</title>', page, flags=re.S)
    page = re.sub(r'<meta name="description" content=".*?">', f'<meta name="description" content="{desc}">', page)
    page = re.sub(r'<meta property="og:title" content=".*?">', f'<meta property="og:title" content="{title}">', page)
    page = re.sub(r'(<div class="nav-links">).*?(</div>)', lambda m: m.group(1) + '\n' + nav_html(fname) + '\n      ' + m.group(2), page, flags=re.S)
    page += body + footer
    open(os.path.join(ROOT, fname), 'w').write(page)
    print('built', fname)
